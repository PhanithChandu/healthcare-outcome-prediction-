from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from xgboost import XGBRegressor
import shap
from lime.lime_tabular import LimeTabularExplainer

RANDOM_STATE = 42
ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "diabetes_progression.csv"
FIGURES = ROOT / "reports" / "figures"
FIGURES.mkdir(parents=True, exist_ok=True)

def main():
    df = pd.read_csv(DATA_PATH)
    X = df.drop(columns="target")
    y = df["target"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=RANDOM_STATE
    )

    # Fit an interpretable XGBoost pipeline.
    pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("model", XGBRegressor(
            n_estimators=300, learning_rate=0.03, max_depth=3,
            subsample=0.8, colsample_bytree=0.8,
            objective="reg:squarederror", random_state=RANDOM_STATE,
            n_jobs=2
        )),
    ])
    pipeline.fit(X_train, y_train)

    X_train_imp = pipeline.named_steps["imputer"].transform(X_train)
    X_test_imp = pipeline.named_steps["imputer"].transform(X_test)
    model = pipeline.named_steps["model"]

    # SHAP global explanation
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X_test_imp)
    plt.figure()
    shap.summary_plot(
        shap_values, X_test_imp, feature_names=X.columns,
        show=False, max_display=10
    )
    plt.tight_layout()
    plt.savefig(FIGURES / "shap_summary.png", dpi=180, bbox_inches="tight")
    plt.close()

    # LIME local explanation
    lime_explainer = LimeTabularExplainer(
        X_train_imp,
        feature_names=list(X.columns),
        mode="regression",
        random_state=RANDOM_STATE
    )
    instance = X_test_imp[0]
    explanation = lime_explainer.explain_instance(
        instance, model.predict, num_features=10
    )
    explanation.save_to_file(str(FIGURES / "lime_explanation.html"))

    print("SHAP and LIME explanations generated.")

if __name__ == "__main__":
    main()
