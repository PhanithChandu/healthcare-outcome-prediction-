from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, KFold, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import ElasticNet
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from xgboost import XGBRegressor

RANDOM_STATE = 42
ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "diabetes_progression.csv"
REPORTS = ROOT / "reports"
FIGURES = REPORTS / "figures"
REPORTS.mkdir(exist_ok=True)
FIGURES.mkdir(parents=True, exist_ok=True)

def evaluate(y_true, y_pred):
    return {
        "MAE": mean_absolute_error(y_true, y_pred),
        "RMSE": np.sqrt(mean_squared_error(y_true, y_pred)),
        "R2": r2_score(y_true, y_pred),
    }

def main():
    df = pd.read_csv(DATA_PATH)
    target = "target"
    X = df.drop(columns=target).copy()
    y = df[target].copy()

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=RANDOM_STATE
    )

    models = {
        "ElasticNet": Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("model", ElasticNet(alpha=0.05, l1_ratio=0.5, max_iter=10000, random_state=RANDOM_STATE)),
        ]),
        "GradientBoosting": Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", GradientBoostingRegressor(
                n_estimators=250, learning_rate=0.03, max_depth=2,
                random_state=RANDOM_STATE
            )),
        ]),
        "XGBoost": Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("model", XGBRegressor(
                n_estimators=300, learning_rate=0.03, max_depth=3,
                subsample=0.8, colsample_bytree=0.8,
                objective="reg:squarederror", random_state=RANDOM_STATE,
                n_jobs=2
            )),
        ]),
    }

    metrics = []
    predictions = {}
    cv = KFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)

    for name, model in models.items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        predictions[name] = pred

        row = {"Model": name, **evaluate(y_test, pred)}
        cv_rmse = np.sqrt(-cross_val_score(
            model, X_train, y_train, cv=cv,
            scoring="neg_mean_squared_error"
        ))
        row["CV_RMSE_Mean"] = cv_rmse.mean()
        row["CV_RMSE_SD"] = cv_rmse.std()
        metrics.append(row)

    metrics_df = pd.DataFrame(metrics).sort_values("RMSE")
    metrics_df.to_csv(REPORTS / "model_metrics.csv", index=False)

    # Model comparison
    ax = metrics_df.plot(x="Model", y=["MAE", "RMSE"], kind="bar", figsize=(9, 5))
    ax.set_title("Model Error Comparison")
    ax.set_ylabel("Error")
    ax.tick_params(axis="x", rotation=0)
    plt.tight_layout()
    plt.savefig(FIGURES / "model_comparison.png", dpi=180)
    plt.close()

    # Actual vs predicted for best model
    best_name = metrics_df.iloc[0]["Model"]
    best_pred = predictions[best_name]
    plt.figure(figsize=(7, 6))
    plt.scatter(y_test, best_pred, alpha=0.7)
    lo, hi = min(y_test.min(), best_pred.min()), max(y_test.max(), best_pred.max())
    plt.plot([lo, hi], [lo, hi], linestyle="--")
    plt.xlabel("Actual progression")
    plt.ylabel("Predicted progression")
    plt.title(f"Actual vs Predicted — {best_name}")
    plt.tight_layout()
    plt.savefig(FIGURES / "actual_vs_predicted.png", dpi=180)
    plt.close()

    # Subgroup analysis using derived groups from standardized age/sex variables.
    # These are benchmark subgroup analyses, not clinical fairness certification.
    test_meta = X_test.copy()
    test_meta["actual"] = y_test.values
    test_meta["prediction"] = best_pred
    test_meta["sex_group"] = np.where(test_meta["sex"] >= 0, "Sex >= 0", "Sex < 0")
    test_meta["age_group"] = np.where(test_meta["age"] >= 0, "Age >= 0", "Age < 0")

    rows = []
    for group_col in ["sex_group", "age_group"]:
        for group, part in test_meta.groupby(group_col):
            rows.append({
                "Subgroup_Type": group_col,
                "Subgroup": group,
                "N": len(part),
                "MAE": mean_absolute_error(part["actual"], part["prediction"]),
                "RMSE": np.sqrt(mean_squared_error(part["actual"], part["prediction"])),
                "R2": r2_score(part["actual"], part["prediction"]) if len(part) > 1 else np.nan,
            })
    pd.DataFrame(rows).to_csv(REPORTS / "subgroup_metrics.csv", index=False)

    print("Training complete.")
    print(metrics_df.to_string(index=False))
    print(f"\nBest model: {best_name}")
    print(f"Reports saved to: {REPORTS}")

if __name__ == "__main__":
    main()
